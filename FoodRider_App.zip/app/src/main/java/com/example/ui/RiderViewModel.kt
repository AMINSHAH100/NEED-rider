package com.example.ui

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class RiderViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        private const val TAG = "RiderViewModel"
    }

    // Screen State: Default is AUTH (Login / Register option screen)
    private val _screenState = MutableStateFlow(ScreenState.AUTH)
    val screenState: StateFlow<ScreenState> = _screenState.asStateFlow()

    // Auth Mode: LOGIN or REGISTER
    private val _authMode = MutableStateFlow(AuthMode.LOGIN)
    val authMode: StateFlow<AuthMode> = _authMode.asStateFlow()

    // Form inputs for Login
    private val _loginIdentifier = MutableStateFlow("")
    val loginIdentifier: StateFlow<String> = _loginIdentifier.asStateFlow()

    private val _loginPassword = MutableStateFlow("")
    val loginPassword: StateFlow<String> = _loginPassword.asStateFlow()

    // Form inputs for Registration
    private val _registrationForm = MutableStateFlow(RiderRegistrationData())
    val registrationForm: StateFlow<RiderRegistrationData> = _registrationForm.asStateFlow()

    private val _isSubmitting = MutableStateFlow(false)
    val isSubmitting: StateFlow<Boolean> = _isSubmitting.asStateFlow()

    private val _isCheckingStatus = MutableStateFlow(false)
    val isCheckingStatus: StateFlow<Boolean> = _isCheckingStatus.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _riderProfile = MutableStateFlow(RiderProfile())
    val riderProfile: StateFlow<RiderProfile> = _riderProfile.asStateFlow()

    // Real-time Incoming Order offer before acceptance
    private val _incomingOrder = MutableStateFlow<DeliveryOrder?>(null)
    val incomingOrder: StateFlow<DeliveryOrder?> = _incomingOrder.asStateFlow()

    // Currently accepted and active order being delivered
    private val _activeOrder = MutableStateFlow<DeliveryOrder?>(null)
    val activeOrder: StateFlow<DeliveryOrder?> = _activeOrder.asStateFlow()

    val locationStreamingManager = LocationStreamingManager(application)

    init {
        // Init anonymous auth quietly in background
        FirebaseRiderService.initAnonymousAuth(
            onSuccess = { user ->
                Log.i(TAG, "Firebase Anonymous Auth ready: ${user.uid}")
            },
            onFailure = { e ->
                Log.e(TAG, "[FirebaseAuth ERROR] Initial auth failed: ${e.message}", e)
            }
        )
    }

    fun setAuthMode(mode: AuthMode) {
        _authMode.value = mode
        _errorMessage.value = null
    }

    fun clearError() {
        _errorMessage.value = null
    }

    fun updateLoginFields(identifier: String? = null, password: String? = null) {
        if (identifier != null) _loginIdentifier.value = identifier
        if (password != null) _loginPassword.value = password
        _errorMessage.value = null
    }

    fun updateFormField(
        fullName: String? = null,
        phoneNumber: String? = null,
        email: String? = null,
        password: String? = null,
        nidNumber: String? = null,
        vehicleType: String? = null,
        vehicleNumber: String? = null,
        licenseNumber: String? = null,
        emergencyContact: String? = null,
        city: String? = null
    ) {
        val current = _registrationForm.value
        _registrationForm.value = current.copy(
            fullName = fullName ?: current.fullName,
            phoneNumber = phoneNumber ?: current.phoneNumber,
            email = email ?: current.email,
            password = password ?: current.password,
            nidNumber = nidNumber ?: current.nidNumber,
            vehicleType = vehicleType ?: current.vehicleType,
            vehicleNumber = vehicleNumber ?: current.vehicleNumber,
            licenseNumber = licenseNumber ?: current.licenseNumber,
            emergencyContact = emergencyContact ?: current.emergencyContact,
            city = city ?: current.city
        )
        _errorMessage.value = null
    }

    /**
     * Submit Real Registration to Firestore.
     */
    fun submitRegistration() {
        val form = _registrationForm.value

        // Strict Validation
        if (form.fullName.trim().length < 3) {
            _errorMessage.value = "দয়া করে আপনার পূর্ণ নাম লিখুন (কমপক্ষে ৩ অক্ষর)"
            return
        }
        if (form.phoneNumber.trim().length < 8) {
            _errorMessage.value = "দয়া করে সঠিক মোবাইল নম্বর লিখুন"
            return
        }
        if (form.password.trim().length < 4) {
            _errorMessage.value = "লগইনের জন্য কমপক্ষে ৪ সংখ্যার পাসওয়ার্ড দিন"
            return
        }
        if (form.vehicleNumber.trim().isBlank()) {
            _errorMessage.value = "যানবাহনের প্লেট নম্বর লিখুন (যেমন: LI 123 AA)"
            return
        }

        _isSubmitting.value = true
        _errorMessage.value = null

        FirebaseRiderService.submitRiderRegistration(
            rider = form,
            onSuccess = { riderId ->
                _isSubmitting.value = false
                Log.i(TAG, "Rider registered successfully! ID=$riderId. Navigating to PENDING_APPROVAL.")

                _riderProfile.value = RiderProfile(
                    riderId = riderId,
                    authUid = riderId,
                    fullName = form.fullName,
                    phoneNumber = form.phoneNumber,
                    email = form.email,
                    vehicleType = form.vehicleType,
                    vehicleNumber = form.vehicleNumber,
                    licenseNumber = form.licenseNumber,
                    nidNumber = form.nidNumber,
                    emergencyContact = form.emergencyContact,
                    city = form.city,
                    status = "pending",
                    isApproved = false
                )

                _screenState.value = ScreenState.PENDING_APPROVAL
                startApprovalListener(riderId)
            },
            onFailure = { e ->
                _isSubmitting.value = false
                val msg = e.localizedMessage ?: "রেজিস্ট্রেশন জমা দেওয়া যায়নি"
                _errorMessage.value = msg
                Log.e(TAG, "Registration failed: $msg", e)
            }
        )
    }

    /**
     * Perform Real Login from Firestore.
     */
    fun login() {
        val id = _loginIdentifier.value.trim()
        val pwd = _loginPassword.value.trim()

        if (id.isBlank()) {
            _errorMessage.value = "দয়া করে মোবাইল নম্বর বা ইমেইল লিখুন"
            return
        }

        _isSubmitting.value = true
        _errorMessage.value = null

        FirebaseRiderService.loginRider(
            phoneOrEmail = id,
            passwordInput = pwd,
            onSuccess = { profile ->
                _isSubmitting.value = false
                _riderProfile.value = profile

                if (profile.isApproved) {
                    Log.i(TAG, "Rider is APPROVED. Entering DASHBOARD.")
                    _screenState.value = ScreenState.DASHBOARD
                    locationStreamingManager.startLocationUpdates()
                } else {
                    Log.i(TAG, "Rider is PENDING. Entering PENDING_APPROVAL.")
                    _screenState.value = ScreenState.PENDING_APPROVAL
                    startApprovalListener(profile.riderId)
                }
            },
            onFailure = { errorMsg ->
                _isSubmitting.value = false
                _errorMessage.value = errorMsg
            }
        )
    }

    /**
     * Listen in real-time to Admin Approval from needadmin.jotpot.it.
     */
    fun startApprovalListener(riderId: String) {
        FirebaseRiderService.listenToApprovalStatus(riderId) { isApproved, status ->
            if (isApproved) {
                Log.i(TAG, "Rider approved by admin! Transitioning to DASHBOARD.")
                _riderProfile.value = _riderProfile.value.copy(
                    status = "approved",
                    isApproved = true
                )
                _screenState.value = ScreenState.DASHBOARD
                locationStreamingManager.startLocationUpdates()
            } else {
                _riderProfile.value = _riderProfile.value.copy(status = status, isApproved = false)
            }
        }
    }

    fun refreshApprovalStatus() {
        val riderId = _riderProfile.value.riderId
        if (riderId.isBlank()) return

        _isCheckingStatus.value = true
        FirebaseRiderService.checkApprovalStatus(riderId) { isApproved, status ->
            _isCheckingStatus.value = false
            if (isApproved) {
                _riderProfile.value = _riderProfile.value.copy(
                    status = "approved",
                    isApproved = true
                )
                _screenState.value = ScreenState.DASHBOARD
                locationStreamingManager.startLocationUpdates()
            } else {
                _riderProfile.value = _riderProfile.value.copy(status = status, isApproved = false)
            }
        }
    }

    fun toggleDutyStatus() {
        val current = _riderProfile.value
        if (!current.isApproved) return

        val newOnline = !current.isOnline
        _riderProfile.value = current.copy(isOnline = newOnline)
        if (newOnline) {
            // Automatically detect live location & broadcast to Firestore
            locationStreamingManager.startLocationUpdates()
            // Start listening for dispatched orders from needadmin.jotpot.it
            FirebaseRiderService.listenToDispatchedOrders { order ->
                if (_activeOrder.value == null) {
                    _incomingOrder.value = order
                }
            }
        } else {
            locationStreamingManager.stopLocationUpdates()
            _incomingOrder.value = null
        }
    }

    /**
     * Accept incoming order after previewing restaurant, client, distance, earnings & payment
     */
    fun acceptOrder(order: DeliveryOrder) {
        FirebaseRiderService.acceptOrder(
            orderId = order.id,
            onSuccess = {
                _activeOrder.value = order.copy(status = "RIDER_ASSIGNED")
                _incomingOrder.value = null
            },
            onFailure = {
                _activeOrder.value = order.copy(status = "RIDER_ASSIGNED")
                _incomingOrder.value = null
            }
        )
    }

    /**
     * Decline / Pass incoming order
     */
    fun rejectOrder(order: DeliveryOrder, reason: String = "Declined by rider") {
        FirebaseRiderService.rejectOrder(order.id, reason) {
            _incomingOrder.value = null
        }
    }

    /**
     * Complete active order delivery and credit rider earnings in Euros (€)
     */
    fun completeActiveOrder() {
        val active = _activeOrder.value ?: return
        val currentProfile = _riderProfile.value
        val earned = active.riderEarningsEuro
        val codCollected = if (active.paymentType == "CASH_ON_DELIVERY") active.totalBillEuro else 0.0

        FirebaseRiderService.updateOrderStatus(active.id, "DELIVERED") {
            _riderProfile.value = currentProfile.copy(
                todayEarnings = currentProfile.todayEarnings + earned,
                todayDeliveries = currentProfile.todayDeliveries + 1,
                cashInHand = currentProfile.cashInHand + codCollected
            )
            _activeOrder.value = null
        }
    }

    /**
     * Test order simulation to verify the 5 requested parameters directly
     */
    fun simulateTestOrder(isBankPaid: Boolean = true) {
        val testOrder = if (isBankPaid) {
            DeliveryOrder(
                id = "ORD-TEST-${System.currentTimeMillis() % 1000}",
                orderNumber = "#IT-7842",
                restaurantName = "Pizzeria Trattoria Da Mario",
                restaurantAddress = "Via Roma 42, 57014 Collesalvetti LI",
                restaurantPhone = "+39 0586 940112",
                restaurantLat = 43.5950,
                restaurantLng = 10.4725,
                customerName = "Marco Rossi",
                customerPhone = "+39 347 1234567",
                customerAddress = "Via Garibaldi 18, Collesalvetti LI (Scala B, Int. 4)",
                customerNote = "দয়া করে বেল বাজান, ৩য় তলায় লিফট আছে",
                customerLat = 43.5840,
                customerLng = 10.4860,
                distanceKm = 4.2,
                estimatedMinutes = 18,
                riderEarningsEuro = 6.80,
                deliveryFeeEuro = 5.50,
                tipEuro = 1.30,
                isBankPaidToRestaurant = true,
                paymentType = "BANK_PAID",
                totalBillEuro = 0.0,
                itemsSummary = "2x Pizza Diavola, 1x Tiramisù, 1x Acqua Minerale",
                status = "READY_FOR_PICKUP"
            )
        } else {
            DeliveryOrder(
                id = "ORD-TEST-${System.currentTimeMillis() % 1000}",
                orderNumber = "#IT-8914",
                restaurantName = "Ristorante Il Mandarino",
                restaurantAddress = "Via Livornese 88, 57014 Collesalvetti LI",
                restaurantPhone = "+39 0586 962341",
                restaurantLat = 43.5990,
                restaurantLng = 10.4680,
                customerName = "Giuseppe Bianchi",
                customerPhone = "+39 340 9876543",
                customerAddress = "Piazza della Repubblica 9, Collesalvetti LI",
                customerNote = "গেট দিয়ে ঢুকে ডান পাশের ডোরবেল চাপুন",
                customerLat = 43.5820,
                customerLng = 10.4910,
                distanceKm = 5.5,
                estimatedMinutes = 22,
                riderEarningsEuro = 8.20,
                deliveryFeeEuro = 6.50,
                tipEuro = 1.70,
                isBankPaidToRestaurant = false,
                paymentType = "CASH_ON_DELIVERY",
                totalBillEuro = 32.50,
                itemsSummary = "1x Spaghetti ai Frutti di Mare, 1x Fritto Misto, 2x Birra Moretti",
                status = "READY_FOR_PICKUP"
            )
        }
        _incomingOrder.value = testOrder
    }

    fun logout() {
        FirebaseRiderService.stopListening()
        locationStreamingManager.stopLocationUpdates()
        _incomingOrder.value = null
        _activeOrder.value = null
        _riderProfile.value = RiderProfile()
        _loginIdentifier.value = ""
        _loginPassword.value = ""
        _registrationForm.value = RiderRegistrationData()
        _screenState.value = ScreenState.AUTH
        _authMode.value = AuthMode.LOGIN
    }

    override fun onCleared() {
        super.onCleared()
        FirebaseRiderService.stopListening()
        locationStreamingManager.stopLocationUpdates()
    }
}
