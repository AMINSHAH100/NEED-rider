package com.example.data

import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions

object FirebaseRiderService {
    private const val TAG = "FirebaseRiderService"
    const val COLLECTION_RIDER_REQUESTS = "rider_requests"
    const val COLLECTION_RIDERS = "riders"

    private val auth: FirebaseAuth
        get() = FirebaseAuth.getInstance()

    private val firestore: FirebaseFirestore
        get() = FirebaseFirestore.getInstance()

    private var requestsListener: ListenerRegistration? = null
    private var ridersListener: ListenerRegistration? = null

    /**
     * Immediately perform Firebase Anonymous Authentication on app launch.
     */
    fun initAnonymousAuth(onSuccess: ((FirebaseUser) -> Unit)? = null, onFailure: ((Exception) -> Unit)? = null) {
        val currentUser = auth.currentUser
        if (currentUser != null) {
            Log.i(TAG, "[FirebaseAuth] User already authenticated: UID=${currentUser.uid}")
            onSuccess?.invoke(currentUser)
            return
        }

        Log.i(TAG, "[FirebaseAuth] Starting signInAnonymously() on app launch...")
        auth.signInAnonymously()
            .addOnSuccessListener { authResult ->
                val user = authResult.user
                if (user != null) {
                    Log.i(TAG, "[FirebaseAuth] signInAnonymously SUCCESS! UID=${user.uid}")
                    onSuccess?.invoke(user)
                } else {
                    val ex = IllegalStateException("Anonymous sign-in succeeded but user is null")
                    Log.e(TAG, "[FirebaseAuth ERROR] $ex")
                    onFailure?.invoke(ex)
                }
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "[FirebaseAuth ERROR] signInAnonymously failed: ${e.message}", e)
                onFailure?.invoke(e)
            }
    }

    /**
     * Ensure user is authenticated before any Firestore write operation.
     */
    fun ensureAuthenticated(onComplete: (FirebaseUser?) -> Unit) {
        val currentUser = auth.currentUser
        if (currentUser != null) {
            onComplete(currentUser)
            return
        }

        Log.w(TAG, "[FirebaseAuth] auth.currentUser is null. Invoking signInAnonymously before proceeding...")
        auth.signInAnonymously()
            .addOnSuccessListener { result ->
                val user = result.user
                Log.i(TAG, "[FirebaseAuth] ensureAuthenticated successful! UID=${user?.uid}")
                onComplete(user)
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "[FirebaseAuth ERROR] ensureAuthenticated failed: ${e.message}", e)
                onComplete(null)
            }
    }

    /**
     * Submit Rider Registration directly to `rider_requests` for Admin Panel,
     * and mirror to `riders` collection.
     * All field variants (id, name, fullName, phone, vehicleType, location, status: 'PENDING') are populated.
     */
    fun submitRiderRegistration(
        rider: RiderRegistrationData,
        onSuccess: (String) -> Unit,
        onFailure: (Exception) -> Unit
    ) {
        ensureAuthenticated { user ->
            val uid = user?.uid ?: "RD-${System.currentTimeMillis() % 100000}"

            val riderData = hashMapOf<String, Any>(
                "id" to uid,
                "riderId" to uid,
                "riderCode" to uid,
                "authUid" to uid,
                "name" to rider.fullName,
                "fullName" to rider.fullName,
                "riderName" to rider.fullName,
                "phone" to rider.phoneNumber,
                "phoneNumber" to rider.phoneNumber,
                "mobile" to rider.phoneNumber,
                "email" to rider.email,
                "password" to rider.password,
                "nidNumber" to rider.nidNumber,
                "nationalId" to rider.nidNumber,
                "vehicleType" to rider.vehicleType,
                "vehicleNumber" to rider.vehicleNumber,
                "plateNumber" to rider.vehicleNumber,
                "licenseNumber" to rider.licenseNumber,
                "emergencyContact" to rider.emergencyContact,
                "location" to rider.city,
                "city" to rider.city,
                "zone" to rider.city,
                "status" to "PENDING",
                "approvalStatus" to "PENDING",
                "isApproved" to false,
                "approved" to false,
                "isOnline" to false,
                "active" to false,
                "role" to "rider",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp(),
                "submittedAt" to System.currentTimeMillis(),
                "latitude" to 43.5933,
                "longitude" to 10.4735
            )

            Log.i(TAG, "[Firestore] Writing rider registration to '$COLLECTION_RIDER_REQUESTS' & '$COLLECTION_RIDERS', doc ID: '$uid'...")

            // Primary: Save directly to rider_requests for the Admin Panel
            firestore.collection(COLLECTION_RIDER_REQUESTS).document(uid)
                .set(riderData, SetOptions.merge())
                .addOnSuccessListener {
                    Log.i(TAG, "[Firestore SUCCESS] Rider registration saved to '$COLLECTION_RIDER_REQUESTS' for Admin Panel! DocID: $uid")

                    // Mirror to riders collection
                    try {
                        firestore.collection(COLLECTION_RIDERS).document(uid).set(riderData, SetOptions.merge())
                        firestore.collection("rider_approvals").document(uid).set(riderData, SetOptions.merge())
                        firestore.collection("admin_approval_requests").document(uid).set(riderData, SetOptions.merge())
                    } catch (syncEx: Throwable) {
                        Log.w(TAG, "[Firestore Aux Sync Warning] ${syncEx.message}")
                    }

                    onSuccess(uid)
                }
                .addOnFailureListener { e ->
                    Log.e(TAG, "[Firestore ERROR] Failed to save to '$COLLECTION_RIDER_REQUESTS': ${e.message}", e)
                    onFailure(e)
                }
        }
    }

    /**
     * Login Rider by Phone Number, Email, or Rider ID from either riders or rider_requests.
     */
    fun loginRider(
        phoneOrEmail: String,
        passwordInput: String,
        onSuccess: (RiderProfile) -> Unit,
        onFailure: (String) -> Unit
    ) {
        val queryText = phoneOrEmail.trim()
        if (queryText.isBlank()) {
            onFailure("দয়া করে মোবাইল নম্বর বা ইমেইল লিখুন")
            return
        }

        ensureAuthenticated {
            firestore.collection(COLLECTION_RIDERS)
                .whereEqualTo("phone", queryText)
                .get()
                .addOnSuccessListener { querySnapshot ->
                    if (!querySnapshot.isEmpty) {
                        val doc = querySnapshot.documents.first()
                        validateAndReturnProfile(doc, passwordInput, onSuccess, onFailure)
                    } else {
                        // Check rider_requests
                        firestore.collection(COLLECTION_RIDER_REQUESTS)
                            .whereEqualTo("phone", queryText)
                            .get()
                            .addOnSuccessListener { reqSnapshot ->
                                if (!reqSnapshot.isEmpty) {
                                    val doc = reqSnapshot.documents.first()
                                    validateAndReturnProfile(doc, passwordInput, onSuccess, onFailure)
                                } else {
                                    // Search by email in riders
                                    firestore.collection(COLLECTION_RIDERS)
                                        .whereEqualTo("email", queryText)
                                        .get()
                                        .addOnSuccessListener { emailSnapshot ->
                                            if (!emailSnapshot.isEmpty) {
                                                val doc = emailSnapshot.documents.first()
                                                validateAndReturnProfile(doc, passwordInput, onSuccess, onFailure)
                                            } else {
                                                // Search by document ID
                                                firestore.collection(COLLECTION_RIDERS).document(queryText).get()
                                                    .addOnSuccessListener { idDoc ->
                                                        if (idDoc != null && idDoc.exists()) {
                                                            validateAndReturnProfile(idDoc, passwordInput, onSuccess, onFailure)
                                                        } else {
                                                            onFailure("এই তথ্যে কোনো রাইডার অ্যাকাউন্ট পাওয়া যায়নি। দয়া করে রেজিস্ট্রেশন করুন।")
                                                        }
                                                    }
                                                    .addOnFailureListener { e ->
                                                        onFailure("লগইন ত্রুটি: ${e.localizedMessage}")
                                                    }
                                            }
                                        }
                                        .addOnFailureListener { e ->
                                            onFailure("লগইন ত্রুটি: ${e.localizedMessage}")
                                        }
                                }
                            }
                            .addOnFailureListener { e ->
                                onFailure("লগইন ত্রুটি: ${e.localizedMessage}")
                            }
                    }
                }
                .addOnFailureListener { e ->
                    onFailure("লগইন সংযোগ সমস্যা: ${e.localizedMessage}")
                }
        }
    }

    private fun validateAndReturnProfile(
        doc: com.google.firebase.firestore.DocumentSnapshot,
        passwordInput: String,
        onSuccess: (RiderProfile) -> Unit,
        onFailure: (String) -> Unit
    ) {
        val storedPassword = doc.getString("password").orEmpty()
        if (storedPassword.isNotBlank() && passwordInput.isNotBlank()) {
            if (storedPassword != passwordInput) {
                onFailure("ভুল পাসওয়ার্ড! দয়া করে সঠিক পাসওয়ার্ড লিখুন।")
                return
            }
        }

        val status = doc.getString("status") ?: doc.getString("approvalStatus") ?: "PENDING"
        val isApproved = doc.getBoolean("isApproved") == true ||
                doc.getBoolean("approved") == true ||
                status.equals("APPROVED", ignoreCase = true)

        val profile = RiderProfile(
            riderId = doc.id,
            authUid = doc.getString("authUid") ?: doc.id,
            fullName = doc.getString("fullName") ?: doc.getString("name") ?: "Rider",
            phoneNumber = doc.getString("phone") ?: doc.getString("phoneNumber").orEmpty(),
            email = doc.getString("email").orEmpty(),
            vehicleType = doc.getString("vehicleType") ?: "Motorcycle",
            vehicleNumber = doc.getString("vehicleNumber") ?: doc.getString("plateNumber").orEmpty(),
            licenseNumber = doc.getString("licenseNumber").orEmpty(),
            nidNumber = doc.getString("nidNumber").orEmpty(),
            emergencyContact = doc.getString("emergencyContact").orEmpty(),
            city = doc.getString("location") ?: doc.getString("city") ?: "Collesalvetti / Livorno",
            status = status,
            isApproved = isApproved,
            isOnline = doc.getBoolean("isOnline") ?: false,
            latitude = doc.getDouble("latitude") ?: 43.5933,
            longitude = doc.getDouble("longitude") ?: 10.4735
        )

        onSuccess(profile)
    }

    /**
     * Real-time listener for Rider approval status.
     * Listens to BOTH `rider_requests` and `riders` collections.
     * When Admin on needadmin.jotpot.it approves in rider_requests, this callback fires immediately!
     */
    fun listenToApprovalStatus(
        riderId: String,
        onStatusChange: (isApproved: Boolean, status: String) -> Unit
    ) {
        stopListening()

        val idToListen = riderId.ifBlank { auth.currentUser?.uid.orEmpty() }
        if (idToListen.isBlank()) {
            Log.w(TAG, "Cannot listen to approval status: riderId is blank")
            return
        }

        Log.i(TAG, "[Firestore] Starting dual real-time approval listeners for rider '$idToListen'...")

        val checkSnapshot: (com.google.firebase.firestore.DocumentSnapshot?, String) -> Unit = { snapshot, collectionName ->
            if (snapshot != null && snapshot.exists()) {
                val status = snapshot.getString("status") ?: snapshot.getString("approvalStatus") ?: "PENDING"
                val isApproved = snapshot.getBoolean("isApproved") == true ||
                        snapshot.getBoolean("approved") == true ||
                        status.equals("APPROVED", ignoreCase = true)

                Log.i(TAG, "[Firestore $collectionName] Live Rider Status: status=$status, isApproved=$isApproved")
                onStatusChange(isApproved, status)
            }
        }

        // 1. Listen to rider_requests (where Admin Panel approves)
        requestsListener = firestore.collection(COLLECTION_RIDER_REQUESTS).document(idToListen)
            .addSnapshotListener { snapshot, error ->
                if (error == null) {
                    checkSnapshot(snapshot, COLLECTION_RIDER_REQUESTS)
                }
            }

        // 2. Listen to riders collection
        ridersListener = firestore.collection(COLLECTION_RIDERS).document(idToListen)
            .addSnapshotListener { snapshot, error ->
                if (error == null) {
                    checkSnapshot(snapshot, COLLECTION_RIDERS)
                }
            }
    }

    /**
     * Manual check for approval status across both collections.
     * Returns "not_registered" if neither document exists.
     */
    fun checkApprovalStatus(
        riderId: String,
        onResult: (Boolean, String) -> Unit
    ) {
        val idToQuery = riderId.ifBlank { auth.currentUser?.uid.orEmpty() }
        if (idToQuery.isBlank()) {
            onResult(false, "not_registered")
            return
        }

        // Check rider_requests first
        firestore.collection(COLLECTION_RIDER_REQUESTS).document(idToQuery).get()
            .addOnSuccessListener { reqDoc ->
                if (reqDoc != null && reqDoc.exists()) {
                    val status = reqDoc.getString("status") ?: reqDoc.getString("approvalStatus") ?: "PENDING"
                    val isApproved = reqDoc.getBoolean("isApproved") == true ||
                            reqDoc.getBoolean("approved") == true ||
                            status.equals("APPROVED", ignoreCase = true)
                    onResult(isApproved, status)
                } else {
                    // Check riders collection
                    firestore.collection(COLLECTION_RIDERS).document(idToQuery).get()
                        .addOnSuccessListener { doc ->
                            if (doc != null && doc.exists()) {
                                val status = doc.getString("status") ?: doc.getString("approvalStatus") ?: "PENDING"
                                val isApproved = doc.getBoolean("isApproved") == true ||
                                        doc.getBoolean("approved") == true ||
                                        status.equals("APPROVED", ignoreCase = true)
                                onResult(isApproved, status)
                            } else {
                                onResult(false, "not_registered")
                            }
                        }
                        .addOnFailureListener {
                            onResult(false, "not_registered")
                        }
                }
            }
            .addOnFailureListener {
                onResult(false, "not_registered")
            }
    }

    /**
     * Update rider's live GPS coordinates in Firestore.
     */
    fun updateLiveLocation(lat: Double, lng: Double) {
        val uid = auth.currentUser?.uid ?: return
        val locData = hashMapOf(
            "latitude" to lat,
            "longitude" to lng,
            "lastLocationUpdate" to FieldValue.serverTimestamp()
        )
        firestore.collection(COLLECTION_RIDERS).document(uid).set(locData, SetOptions.merge())
        firestore.collection(COLLECTION_RIDER_REQUESTS).document(uid).set(locData, SetOptions.merge())
    }

    private var ordersListener: ListenerRegistration? = null

    /**
     * Listen to new dispatched orders in Firestore `orders` collection in real-time.
     */
    fun listenToDispatchedOrders(
        onOrderReceived: (DeliveryOrder) -> Unit
    ) {
        ordersListener?.remove()

        Log.i(TAG, "[Firestore] Listening for dispatched orders in 'orders' collection...")

        ordersListener = firestore.collection("orders")
            .whereIn("orderStatus", listOf("READY_FOR_PICKUP", "Ready For Handover", "DISPATCHED", "PENDING_RIDER", "PENDING"))
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Error listening for orders: ${error.message}", error)
                    return@addSnapshotListener
                }

                if (snapshot != null && !snapshot.isEmpty) {
                    for (doc in snapshot.documents) {
                        val assignedRider = doc.getString("riderId") ?: ""
                        val currentUid = auth.currentUser?.uid ?: ""
                        if (assignedRider.isNotBlank() && assignedRider != currentUid) {
                            continue
                        }

                        val orderId = doc.id
                        val orderNumber = doc.getString("orderNumber") ?: "#ORD-${orderId.take(6).uppercase()}"
                        
                        // 1. Restaurant details
                        val restaurantName = doc.getString("restaurantName") ?: "Pizzeria Ristorante Collesalvetti"
                        val restaurantAddress = doc.getString("restaurantAddress") ?: "Via Roma 12, 57014 Collesalvetti LI"
                        val restaurantPhone = doc.getString("restaurantPhone") ?: "+39 0586 940001"

                        // 2. Customer details
                        val customerName = doc.getString("customerName") ?: "Cliente"
                        val customerPhone = doc.getString("customerPhone") ?: "+39 340 0000000"
                        val customerAddress = doc.getString("customerAddress") ?: "Via Garibaldi 45, Collesalvetti LI"
                        val customerNote = doc.getString("customerNote") ?: ""

                        // 3. Distance in KM
                        val distanceKm = doc.getDouble("distanceKm") ?: 3.8
                        val estimatedMins = (doc.getLong("estimatedMinutes") ?: 18).toInt()

                        // 4. Rider Fee / Earnings in Euros (€)
                        val deliveryFee = doc.getDouble("deliveryFee") ?: doc.getDouble("riderFee") ?: 5.50
                        val surgeBonus = doc.getDouble("surgeBonus") ?: 0.0
                        val riderEarnings = deliveryFee + surgeBonus

                        // 5. Payment details: Bank Paid vs Cash On Delivery
                        val paymentMethodRaw = doc.getString("paymentMethod") ?: doc.getString("paymentType") ?: "ONLINE"
                        val isCod = paymentMethodRaw.contains("COD", ignoreCase = true) || paymentMethodRaw.contains("CASH", ignoreCase = true)
                        
                        // Restaurant settlement: Has customer paid restaurant by Bank/Card online?
                        val isBankPaid = !isCod || doc.getBoolean("isBankPaid") == true || doc.getBoolean("isPaid") == true
                        val paymentType = if (isCod) "CASH_ON_DELIVERY" else "BANK_PAID"

                        val totalBill = doc.getDouble("totalBill") ?: doc.getDouble("totalAmount") ?: 24.50
                        val collectAmount = if (isCod) totalBill else 0.0

                        val itemsSummary = doc.getString("itemsSummary") ?: "2x Pizza Margherita, 1x Coca-Cola"

                        val restLat = doc.getDouble("restaurantLat") ?: doc.getDouble("pickupLat") ?: 43.5933
                        val restLng = doc.getDouble("restaurantLng") ?: doc.getDouble("pickupLng") ?: 10.4735
                        val custLat = doc.getDouble("customerLat") ?: doc.getDouble("dropoffLat") ?: 43.5850
                        val custLng = doc.getDouble("customerLng") ?: doc.getDouble("dropoffLng") ?: 10.4850

                        val order = DeliveryOrder(
                            id = orderId,
                            orderNumber = orderNumber,
                            restaurantName = restaurantName,
                            restaurantAddress = restaurantAddress,
                            restaurantPhone = restaurantPhone,
                            restaurantLat = restLat,
                            restaurantLng = restLng,
                            customerName = customerName,
                            customerPhone = customerPhone,
                            customerAddress = customerAddress,
                            customerNote = customerNote,
                            customerLat = custLat,
                            customerLng = custLng,
                            distanceKm = distanceKm,
                            estimatedMinutes = estimatedMins,
                            riderEarningsEuro = riderEarnings,
                            deliveryFeeEuro = deliveryFee,
                            tipEuro = 0.0,
                            isBankPaidToRestaurant = isBankPaid,
                            paymentType = paymentType,
                            totalBillEuro = collectAmount,
                            itemsSummary = itemsSummary,
                            status = doc.getString("orderStatus") ?: "READY_FOR_PICKUP"
                        )

                        onOrderReceived(order)
                        break // Show one order offer at a time
                    }
                }
            }
    }

    fun acceptOrder(
        orderId: String,
        onSuccess: () -> Unit,
        onFailure: (Exception) -> Unit
    ) {
        val uid = auth.currentUser?.uid ?: ""
        val updateData = hashMapOf<String, Any>(
            "orderStatus" to "RIDER_ASSIGNED",
            "status" to "RIDER_ASSIGNED",
            "riderId" to uid,
            "assignedAt" to FieldValue.serverTimestamp()
        )
        firestore.collection("orders").document(orderId)
            .set(updateData, SetOptions.merge())
            .addOnSuccessListener {
                Log.i(TAG, "Order $orderId accepted by rider $uid")
                onSuccess()
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Failed to accept order $orderId: ${e.message}", e)
                onFailure(e)
            }
    }

    fun rejectOrder(
        orderId: String,
        reason: String = "Declined by rider",
        onSuccess: () -> Unit
    ) {
        val uid = auth.currentUser?.uid ?: ""
        val updateData = hashMapOf<String, Any>(
            "lastDeclinedByRider" to uid,
            "declinedAt" to FieldValue.serverTimestamp(),
            "declineReason" to reason
        )
        firestore.collection("orders").document(orderId)
            .set(updateData, SetOptions.merge())
            .addOnSuccessListener {
                onSuccess()
            }
            .addOnFailureListener {
                onSuccess()
            }
    }

    fun updateOrderStatus(
        orderId: String,
        newStatus: String,
        onSuccess: () -> Unit
    ) {
        val updateData = hashMapOf<String, Any>(
            "orderStatus" to newStatus,
            "status" to newStatus,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        firestore.collection("orders").document(orderId)
            .set(updateData, SetOptions.merge())
            .addOnSuccessListener {
                onSuccess()
            }
    }

    fun stopListening() {
        requestsListener?.remove()
        requestsListener = null
        ridersListener?.remove()
        ridersListener = null
        ordersListener?.remove()
        ordersListener = null
    }
}
